README for 4CH_Scanner_Board Fabrication Files

DIMENSIONS: 160mm x 100mm


STACKUP: 4-Layer standard stackup. FR-4

ORDER OF LAYERS: 
GTL - Top Layer
G1  - Inner Layer 1
G2  - Inner Layer 2
GBL - Bottom Layer

OUTLINE:
GKO is Outline Layer

DRILL:
NC Drill File is 4CH_Scanner_Board.TXT
INCH 2:4 format
Smallest Drill is 0.25mm
All Vias are 0.25mm Drill 0.50mm diameter


Thank you!